import { Bookings } from './bookings';

describe('Bookings', () => {
  it('should create an instance', () => {
    expect(new Bookings()).toBeTruthy();
  });
});
