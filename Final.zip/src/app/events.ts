export class Events {
    id:any;
    name:any;
    price:any;
    category:any;
    location:any;
    organiser:any;
    date:any
}
