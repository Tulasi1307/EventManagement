import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Events } from '../events';

@Component({
  selector: 'app-organiser-dashboard',
  templateUrl: './organiser-dashboard.component.html',
  styleUrls: ['./organiser-dashboard.component.css']
})
export class OrganiserDashboardComponent  {
//   events:Events[] | any;
//   organiser:any;
//   constructor(private router:Router ){}
//   eventlist(organiser:string){
//     this.router.navigate(['organiser-event-list',organiser])
//  }
}
