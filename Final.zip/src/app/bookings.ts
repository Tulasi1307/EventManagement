export class Bookings {
    bookingId:any;
    booking_date:any;
    event:any;
    user:any;
}
