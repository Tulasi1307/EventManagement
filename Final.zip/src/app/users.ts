export class Users {
    id:any;
    fullname:any;
    email:any;
    mobileno:any;
    password:any;
    confirmpassword:any;
}
